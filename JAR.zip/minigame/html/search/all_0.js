var searchData=
[
  ['branch_0',['Branch',['../classminigame_1_1_branch.html',1,'minigame']]]
];
