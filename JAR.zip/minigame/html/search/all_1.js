var searchData=
[
  ['credit_0',['credit',['../classminigame_1_1credit.html',1,'minigame']]]
];
