package minigame;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.Group;

public class minigames extends Application {
	
	protected Scene homePage;
	protected final int root_width = 900;
	protected final int root_height = 800;
	
	public void CreateHomePage() {
	
//buttons
		Button rabbitButton = new Button();
	    setButton(rabbitButton, new Image("/minigame/media/rabbit.JPG"), 200);
	    setPosition(rabbitButton, 295, 220);
	    rabbitButton.setOnAction(e-> {
	    	GameFrame gFrame=new GameFrame();
			gFrame.dispose();
		});

		Button dogButton = new Button();
		setButton(dogButton, new Image("/minigame/media/dog.JPG"), 200);
		setPosition(dogButton, 100, 500);
		dogButton.setOnAction(e -> {
			Timberdog timberdogList = new Timberdog();
		    Stage window = (Stage) dogButton.getScene().getWindow();
		    window.setTitle("Timber-dog");
		    window.setScene(new Scene(timberdogList.getTimberdogContent()));
		});

		Button chameleonButton = new Button();
		setButton(chameleonButton, new Image("/minigame/media/chameleon.JPG"), 200);
		setPosition(chameleonButton, 490, 500);
		chameleonButton.setOnAction(e -> {
			PinBall pinball = new PinBall();
			Stage window = (Stage) chameleonButton.getScene().getWindow();
			window.setTitle("Pinball-chameleon");
			window.setScene(new Scene(pinball.getPinBallContent()));
		});	
		
		Button monkeyButton = new Button();
		setButton(monkeyButton, new Image("/minigame/media/monkey.png"), 50);
		setPosition(monkeyButton, 10, 10);
		monkeyButton.setOnAction(e -> {
			credit creditList = new credit();
			Stage window = (Stage) monkeyButton.getScene().getWindow();
			window.setTitle("Credit");
			window.setScene(new Scene(creditList.CreateContent()));
		});
		
		Button goBack = new Button();
		setButton(goBack, new Image("/minigame/media/go_back.jpg"), 50);
		setPosition(goBack, 10, 10);
		goBack.setOnAction(e -> {
			Stage window = (Stage) goBack.getScene().getWindow();
			window.setTitle("Animals party");
			CreateHomePage();
			window.setScene(homePage);
		});
		
//images
		ImageView logoView=new ImageView(new Image("/minigame/media/animals_party.png"));
		logoView.setFitHeight(200);
		logoView.setPreserveRatio(true);
		logoView.setTranslateX(300);
		
//labels
	    Label rabbitText = new Label("Pac-rabbit");
	    setPosition(rabbitText, 365, 440);
	    rabbitText.getStyleClass().add("rabbitText");
	   
	    Label dogText = new Label("Timber-dog");
	    setPosition(dogText, 160, 720);
	    dogText.getStyleClass().add("dogText");
	   
	    Label chameleonText = new Label("Pinball-chameleon");
	    setPosition(chameleonText, 500, 720);
	    chameleonText.getStyleClass().add("chameleonText");
	   
	    Label creditText = new Label("Credit");
	    setPosition(creditText, 25, 70);
	    creditText.getStyleClass().add("creditText");

//
		Group root = new Group(rabbitButton, dogButton, chameleonButton, monkeyButton, rabbitText, dogText, chameleonText, creditText, logoView);
		
		homePage=new Scene(root, 900, 800, Color.AZURE);
		homePage.getStylesheets().add(getClass().getResource("minigame.css").toExternalForm());
		
	}
	
	public void setButton(Button button, Image image, int height) {
		ImageView imageView = new ImageView(image);
		imageView.setFitHeight(height);
		imageView.setPreserveRatio(true);
	    button.setGraphic(imageView);
	}
	
	public static void setPosition(Control item, int x, int y) {
		item.setTranslateX(x);
		item.setTranslateY(y);
	}
	
	public static void setPosition(ImageView item, int x, int y) {
		item.setX(x);
		item.setY(y);
	}
	
	public static void setSize(ImageView view, int width, int height) {
		view.setFitWidth(width);
		view.setFitHeight(height);
	}
	
	public void operationTip(Text text) {
		text.setFont(Font.font("Arial", 40));
		text.setFill(Color.BLACK);
		text.setX(120);
		text.setY(780);
		text.setText("press A and D to move left and right");
	}
	
	public void setGoBackButton(Button goBack) {
		setButton(goBack, new Image("/minigame/media/go_back.jpg"), 50);
		setPosition(goBack, 10, 10);
		goBack.setOnAction(e -> {
			Stage window = (Stage) goBack.getScene().getWindow();
			window.setTitle("Animals party");
			CreateHomePage();
			window.setScene(homePage);
		});
	}
	
	public static void main(String[] args) {
		launch(args);
	}

	@Override
	public void start(Stage stage) throws Exception {		
		stage.setTitle("Minigame");
		CreateHomePage();
		stage.setScene(homePage);
		stage.show();
	}
}