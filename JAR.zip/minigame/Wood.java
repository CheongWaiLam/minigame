package minigame;

import java.util.ArrayList;
import java.util.Random;

public class Wood extends Timberdog {
	public ArrayList<Integer> scores = new ArrayList<>();

	public static void spawnBranches() {
		  Random rng = new Random();
		  int random = rng.nextInt(2);
		  if (random == 0) {
			  wood1X = woodLeftX;
		  } else if (random == 1) {
			  wood1X = woodRightX;
		  }
		  setPosition(woodview, wood1X, wood1Y);
		  setPosition(wood2view, wood1X, wood1Y);
		  root.getChildren().addAll(woodview, wood2view);  
	}
		 
}
